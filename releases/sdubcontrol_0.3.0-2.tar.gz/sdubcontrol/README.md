# sdubcontrol
a repository for playing with national Salmonella Dublin control programme parameters
