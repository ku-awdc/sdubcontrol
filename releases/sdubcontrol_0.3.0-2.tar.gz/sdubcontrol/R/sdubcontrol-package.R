#' @name sdubcontrol-package
#' @title A Shiny Application Illustrating Salmonella Dublin Control
#' @aliases sdubcontrol
#'
#' @details
#' Some description of the package
#'
#' @seealso
#' \code{\link[neatpkg]{pkg_new}} for the function that created this package
#'
#' @references
#' Some article that you might want users to look at
#'
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
